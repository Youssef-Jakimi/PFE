-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2025 at 12:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pfe`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `nom`, `created_at`, `updated_at`) VALUES
(1, 'Chambre', NULL, NULL),
(2, 'Table', NULL, NULL),
(3, 'Spa', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `detail_reservations`
--

CREATE TABLE `detail_reservations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `reservation_id` bigint(20) UNSIGNED NOT NULL,
  `produit_id` bigint(20) UNSIGNED NOT NULL,
  `Prix_Total` int(11) DEFAULT NULL,
  `Date_D` date NOT NULL,
  `Date_F` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `detail_reservations`
--

INSERT INTO `detail_reservations` (`id`, `reservation_id`, `produit_id`, `Prix_Total`, `Date_D`, `Date_F`, `created_at`, `updated_at`) VALUES
(93, 34, 4, 200, '2025-03-21', NULL, '2025-03-01 13:13:49', '2025-03-01 13:13:49'),
(94, 34, 1, 350, '2025-06-18', '2025-06-26', '2025-03-01 13:13:49', '2025-03-01 13:13:49'),
(95, 35, 1, 350, '2025-03-05', '2025-03-12', '2025-03-01 18:59:53', '2025-03-01 18:59:53'),
(96, 35, 1, 350, '2025-03-21', '2025-03-29', '2025-03-01 18:59:53', '2025-03-01 18:59:53'),
(97, 36, 4, 200, '2025-03-12', NULL, '2025-03-07 11:10:37', '2025-03-07 11:10:37'),
(98, 36, 5, 350, '2025-03-21', NULL, '2025-03-07 11:10:37', '2025-03-07 11:10:37'),
(99, 37, 4, 200, '2025-03-15', NULL, '2025-03-07 11:11:23', '2025-03-07 11:11:23'),
(100, 38, 5, 350, '2025-05-20', NULL, '2025-03-18 10:15:25', '2025-03-18 10:15:25'),
(101, 39, 5, 350, '2025-05-21', NULL, '2025-03-18 10:16:52', '2025-03-18 10:16:52'),
(102, 40, 4, 200, '2025-03-28', NULL, '2025-03-18 10:41:03', '2025-03-18 10:41:03'),
(103, 41, 5, 350, '2025-03-27', NULL, '2025-03-18 10:42:20', '2025-03-18 10:42:20'),
(104, 42, 5, 350, '2025-03-23', NULL, '2025-03-18 10:46:30', '2025-03-18 10:46:30'),
(105, 43, 4, 200, '2025-03-22', NULL, '2025-03-18 13:59:06', '2025-03-18 13:59:06'),
(107, 45, 1, 350, '2025-04-18', '2025-04-19', '2025-04-02 04:36:55', '2025-04-02 04:36:55'),
(109, 47, 4, 200, '2025-04-24', '2025-04-30', '2025-04-02 16:15:17', '2025-04-02 16:15:17'),
(110, 48, 3, 200, '2025-04-08', '2025-04-15', '2025-04-02 16:59:14', '2025-04-02 16:59:14'),
(111, 49, 3, 200, '2025-04-18', '2025-04-22', '2025-04-03 00:18:28', '2025-04-03 00:18:28'),
(112, 50, 4, 200, '2025-04-11', '2025-04-20', '2025-04-03 00:55:11', '2025-04-03 00:55:11'),
(113, 50, 4, 200, '2025-04-11', '2025-04-20', '2025-04-03 00:55:11', '2025-04-03 00:55:11'),
(114, 50, 5, 2450, '2025-04-18', '2025-04-25', '2025-04-03 00:55:11', '2025-04-03 00:55:11'),
(115, 51, 1, 2450, '2025-05-08', '2025-05-15', '2025-04-03 12:01:52', '2025-04-03 12:01:52'),
(116, 52, 8, 4550, '2025-04-16', '2025-04-23', '2025-04-04 23:40:29', '2025-04-04 23:40:29'),
(117, 53, 3, 2800, '2025-05-02', '2025-05-16', '2025-04-05 00:08:23', '2025-04-05 00:08:23'),
(118, 54, 4, 0, '2025-06-13', '2025-06-13', '2025-04-05 15:05:13', '2025-04-05 15:05:13'),
(119, 54, 5, 350, '2025-06-13', NULL, '2025-04-05 15:05:13', '2025-04-05 15:05:13'),
(120, 54, 5, 350, '2025-06-13', NULL, '2025-04-05 15:05:13', '2025-04-05 15:05:13'),
(121, 55, 10, 200, '2025-04-18', NULL, '2025-04-05 15:08:40', '2025-04-05 15:08:40'),
(122, 55, 3, 1400, '2025-06-13', '2025-06-20', '2025-04-05 15:08:40', '2025-04-05 15:08:40'),
(123, 56, 11, 350, '2025-04-19', '2025-04-19', '2025-04-05 17:22:18', '2025-04-05 17:22:18'),
(124, 57, 1, 4900, '2025-04-20', '2025-05-04', '2025-04-06 01:51:24', '2025-04-06 01:51:24'),
(125, 57, 8, 4550, '2025-06-12', '2025-06-19', '2025-04-06 01:51:24', '2025-04-06 01:51:24'),
(126, 58, 12, 3500, '2025-04-18', '2025-04-25', '2025-04-06 14:36:18', '2025-04-06 14:36:18'),
(127, 59, 14, 150, '2025-04-12', NULL, '2025-04-06 14:41:20', '2025-04-06 14:41:20'),
(128, 59, 18, 150, '2025-04-12', NULL, '2025-04-06 14:41:20', '2025-04-06 14:41:20'),
(131, 62, 8, 1300, '2025-04-24', '2025-04-26', '2025-04-09 14:34:58', '2025-04-09 14:34:58'),
(133, 63, 5, 350, '2025-04-26', NULL, '2025-04-09 14:44:05', '2025-04-09 14:44:05');

-- --------------------------------------------------------

--
-- Table structure for table `factures`
--

CREATE TABLE `factures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Montant_Total` double DEFAULT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `utilisateur_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `factures`
--

INSERT INTO `factures` (`id`, `Montant_Total`, `Date`, `utilisateur_id`, `created_at`, `updated_at`) VALUES
(2, NULL, '2024-12-04', 9, '2024-12-04 21:23:09', '2024-12-05 12:38:46'),
(3, NULL, '2024-12-04', 9, '2024-12-04 21:24:15', '2024-12-04 21:24:15'),
(4, NULL, '2024-12-05', 9, '2024-12-05 12:37:57', '2024-12-05 12:37:57'),
(5, NULL, '2024-12-17', 9, '2024-12-17 08:10:21', '2024-12-17 08:10:21'),
(6, NULL, '2025-02-18', 11, '2025-02-18 16:48:51', '2025-02-18 16:48:51'),
(7, NULL, '2025-02-18', 11, '2025-02-18 16:49:38', '2025-02-18 16:49:38'),
(8, NULL, '2025-02-18', 11, '2025-02-18 16:49:58', '2025-02-18 16:49:58'),
(9, NULL, '2025-02-18', 11, '2025-02-18 16:51:02', '2025-02-18 16:51:02'),
(10, NULL, '2025-02-18', 11, '2025-02-18 16:52:20', '2025-02-18 16:52:20'),
(11, NULL, '2025-02-18', 11, '2025-02-18 16:53:52', '2025-02-18 16:53:52'),
(12, 4500, '2025-02-18', 11, '2025-02-18 16:56:22', '2025-02-18 16:56:22'),
(13, 0, '2025-02-18', 11, '2025-02-18 17:32:00', '2025-02-18 17:32:00'),
(14, 0, '2025-02-19', 11, '2025-02-18 22:08:47', '2025-02-18 22:08:47'),
(15, 0, '2025-02-19', 11, '2025-02-18 22:19:30', '2025-02-18 22:19:30'),
(16, 0, '2025-02-19', 11, '2025-02-19 12:56:46', '2025-02-19 12:56:46'),
(17, 0, '2025-02-19', 11, '2025-02-19 12:56:53', '2025-02-19 12:56:53'),
(18, 0, '2025-02-19', 11, '2025-02-19 12:57:00', '2025-02-19 12:57:00'),
(19, 0, '2025-02-19', 11, '2025-02-19 13:02:37', '2025-02-19 13:02:37'),
(20, NULL, '2025-02-19', 11, '2025-02-19 13:08:44', '2025-02-19 13:08:44'),
(21, 0, '2025-02-21', 11, '2025-02-21 08:05:26', '2025-02-21 08:05:26'),
(22, 0, '2025-02-21', 11, '2025-02-21 09:22:28', '2025-02-21 09:22:28'),
(23, 0, '2025-02-21', 11, '2025-02-21 09:24:53', '2025-02-21 09:24:53'),
(24, 0, '2025-02-27', 11, '2025-02-27 18:39:56', '2025-02-27 18:39:56'),
(25, 550, '2025-02-27', 11, '2025-02-27 19:34:09', '2025-02-27 19:34:09'),
(26, 700, '2025-02-27', 11, '2025-02-27 19:48:43', '2025-02-27 19:48:43'),
(27, 200, '2025-02-28', 11, '2025-02-28 12:05:39', '2025-02-28 12:05:39'),
(28, 350, '2025-03-01', 11, '2025-03-01 12:48:17', '2025-03-01 12:48:17'),
(29, 550, '2025-03-01', 11, '2025-03-01 13:13:49', '2025-03-01 13:13:49'),
(30, 700, '2025-03-01', 11, '2025-03-01 18:59:53', '2025-03-01 18:59:53'),
(31, 550, '2025-03-07', 11, '2025-03-07 11:10:37', '2025-03-07 11:10:37'),
(32, 200, '2025-03-07', 11, '2025-03-07 11:11:23', '2025-03-07 11:11:23'),
(33, 350, '2025-03-18', 11, '2025-03-18 10:15:25', '2025-03-18 10:15:25'),
(34, 350, '2025-03-18', 11, '2025-03-18 10:16:52', '2025-03-18 10:16:52'),
(35, 200, '2025-03-18', 12, '2025-03-18 10:41:03', '2025-03-18 10:41:03'),
(36, 350, '2025-03-18', 11, '2025-03-18 10:42:20', '2025-03-18 10:42:20'),
(37, 350, '2025-03-18', 12, '2025-03-18 10:46:30', '2025-03-18 10:46:30'),
(38, 200, '2025-03-18', 11, '2025-03-18 13:59:06', '2025-03-18 13:59:06'),
(39, 350, '2025-04-02', 11, '2025-04-02 04:33:31', '2025-04-02 04:33:31'),
(40, 350, '2025-04-02', 11, '2025-04-02 04:36:55', '2025-04-02 04:36:55'),
(41, 350, '2025-04-02', 11, '2025-04-02 04:38:06', '2025-04-02 04:38:06'),
(42, 200, '2025-04-02', 11, '2025-04-02 16:15:17', '2025-04-02 16:15:17'),
(43, 200, '2025-04-02', 11, '2025-04-02 16:59:14', '2025-04-02 16:59:14'),
(44, 200, '2025-04-03', 11, '2025-04-03 00:18:28', '2025-04-03 00:18:28'),
(45, 2850, '2025-04-03', 11, '2025-04-03 00:55:11', '2025-04-03 00:55:11'),
(46, 2450, '2025-04-03', 11, '2025-04-03 12:01:52', '2025-04-03 12:01:52'),
(47, 4550, '2025-04-04', 12, '2025-04-04 23:40:29', '2025-04-04 23:40:29'),
(48, 2800, '2025-04-05', 11, '2025-04-05 00:08:23', '2025-04-05 00:08:23'),
(49, 700, '2025-04-05', 11, '2025-04-05 15:05:13', '2025-04-05 15:05:13'),
(50, 1600, '2025-04-05', 11, '2025-04-05 15:08:40', '2025-04-05 15:08:40'),
(51, 350, '2025-04-05', 11, '2025-04-05 17:22:18', '2025-04-05 17:22:18'),
(52, 9450, '2025-04-06', 11, '2025-04-06 01:51:24', '2025-04-06 01:51:24'),
(53, 3500, '2025-04-06', 12, '2025-04-06 14:36:18', '2025-04-06 14:36:18'),
(54, 300, '2025-04-06', 12, '2025-04-06 14:41:20', '2025-04-06 14:41:20'),
(55, 400, '2025-04-06', 12, '2025-04-06 14:51:31', '2025-04-06 14:51:31'),
(56, 200, '2025-04-09', 12, '2025-04-09 14:19:18', '2025-04-09 14:19:18'),
(57, 1500, '2025-04-09', 12, '2025-04-09 14:34:58', '2025-04-09 14:34:58'),
(58, 350, '2025-04-09', 12, '2025-04-09 14:44:05', '2025-04-09 14:44:05'),
(59, 0, '2025-04-09', 12, '2025-04-09 15:13:19', '2025-04-09 15:13:19');

-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE `mails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `Utilisateur` bigint(20) UNSIGNED DEFAULT NULL,
  `Message` varchar(255) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mails`
--

INSERT INTO `mails` (`id`, `email`, `Utilisateur`, `Message`, `Date`, `created_at`, `updated_at`) VALUES
(1, 'aerzcze@dcedc.ce', 11, 'v rjnciequrchnuqerivpjsbdiufr', '2025-03-01', '2025-03-01 11:03:58', '2025-03-01 11:03:58'),
(2, 'azerty@gm.cd', NULL, 'endi problem', '2025-04-02', '2025-04-02 23:43:53', '2025-04-02 23:43:53'),
(3, 'test@test.ma', 12, 'this is a test contact message', '2025-04-09', '2025-04-09 15:27:12', '2025-04-09 15:27:12'),
(4, 'test@test.ma', 12, 'this is a test contact message', '2025-04-09', '2025-04-09 15:27:36', '2025-04-09 15:27:36');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_11_03_195406_create_utilisateurs_table', 2),
(5, '2024_11_04_140644_create_reservations_table', 3),
(6, '2024_11_04_140744_create_factures_table', 4),
(7, '2024_11_04_140826_create_categories_table', 4),
(8, '2024_11_04_140842_create_mails_table', 4),
(9, '2024_11_04_140922_create_hotels_table', 4),
(10, '2024_11_04_140726_create_produits_table', 5),
(11, '2024_11_04_140804_create_detail_reservations_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `paniers`
--

CREATE TABLE `paniers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `utilisateur_id` bigint(20) UNSIGNED NOT NULL,
  `produit_id` bigint(20) UNSIGNED NOT NULL,
  `Prix_Total` int(11) DEFAULT NULL,
  `Date_D` date NOT NULL,
  `Date_F` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `produits`
--

CREATE TABLE `produits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `PR_CODE` varchar(11) NOT NULL,
  `PR_PERSONNE` int(11) NOT NULL,
  `PR_CATEGORIE` bigint(20) UNSIGNED NOT NULL,
  `PR_PRIX` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `produits`
--

INSERT INTO `produits` (`id`, `PR_CODE`, `PR_PERSONNE`, `PR_CATEGORIE`, `PR_PRIX`, `created_at`, `updated_at`) VALUES
(1, 'CH-101', 5, 1, 350, '2025-04-05 16:58:02', NULL),
(3, 'CH-102', 5, 1, 200, NULL, NULL),
(4, 'TB-16', 3, 2, 200, NULL, NULL),
(5, 'SPA-X15', 2, 3, 350, NULL, NULL),
(8, 'CH-103', 3, 1, 650, NULL, NULL),
(10, 'TB-17', 3, 2, 200, NULL, NULL),
(11, 'CH-104', 2, 1, 350, NULL, NULL),
(12, 'CH-105', 4, 1, 500, NULL, NULL),
(13, 'CH-106', 1, 1, 200, NULL, NULL),
(14, 'TB-023', 2, 2, 150, NULL, NULL),
(15, 'TB-024', 1, 2, 120, NULL, NULL),
(16, 'TB-025', 3, 2, 200, NULL, NULL),
(17, 'SPA-016', 1, 3, 100, NULL, NULL),
(18, 'SPA-017', 2, 3, 150, NULL, NULL),
(19, 'SPA-018', 1, 3, 80, NULL, NULL),
(21, 'SPA-12', 3, 3, 299, '2025-04-06 00:28:29', '2025-04-06 00:28:29');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `utilisateur_id` bigint(20) UNSIGNED NOT NULL,
  `facture` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `Date`, `utilisateur_id`, `facture`, `created_at`, `updated_at`) VALUES
(9, '2024-12-04 22:23:09', 9, 2, '2024-12-04 21:23:09', '2024-12-04 21:23:09'),
(10, '2024-12-04 22:24:15', 9, 3, '2024-12-04 21:24:15', '2024-12-04 21:24:15'),
(11, '2024-12-05 13:37:57', 9, 4, '2024-12-05 12:37:57', '2024-12-05 12:37:57'),
(12, '2025-02-15 14:35:18', 11, 5, '2024-12-17 08:10:21', '2024-12-17 08:10:21'),
(13, '2025-02-18 17:49:58', 11, 8, '2025-02-18 16:49:58', '2025-02-18 16:49:58'),
(14, '2025-02-18 17:51:02', 11, 9, '2025-02-18 16:51:02', '2025-02-18 16:51:02'),
(15, '2025-02-18 17:52:20', 11, 10, '2025-02-18 16:52:20', '2025-02-18 16:52:20'),
(16, '2025-02-18 17:53:52', 11, 11, '2025-02-18 16:53:52', '2025-02-18 16:53:52'),
(17, '2025-02-18 17:56:22', 11, 12, '2025-02-18 16:56:22', '2025-02-18 16:56:22'),
(18, '2025-02-18 18:32:00', 11, 13, '2025-02-18 17:32:00', '2025-02-18 17:32:00'),
(19, '2025-02-18 23:08:47', 11, 14, '2025-02-18 22:08:47', '2025-02-18 22:08:47'),
(20, '2025-02-18 23:19:30', 11, 15, '2025-02-18 22:19:30', '2025-02-18 22:19:30'),
(21, '2025-02-19 13:56:46', 11, 16, '2025-02-19 12:56:46', '2025-02-19 12:56:46'),
(22, '2025-02-19 13:56:53', 11, 17, '2025-02-19 12:56:53', '2025-02-19 12:56:53'),
(23, '2025-02-19 13:57:00', 11, 18, '2025-02-19 12:57:00', '2025-02-19 12:57:00'),
(24, '2025-02-19 14:02:37', 11, 19, '2025-02-19 13:02:37', '2025-02-19 13:02:37'),
(25, '2025-02-19 14:08:44', 11, 20, '2025-02-19 13:08:44', '2025-02-19 13:08:44'),
(26, '2025-02-21 09:05:26', 11, 21, '2025-02-21 08:05:26', '2025-02-21 08:05:26'),
(27, '2025-02-21 10:22:28', 11, 22, '2025-02-21 09:22:28', '2025-02-21 09:22:28'),
(28, '2025-02-21 10:24:53', 11, 23, '2025-02-21 09:24:53', '2025-02-21 09:24:53'),
(29, '2025-02-27 18:39:56', 11, 24, '2025-02-27 18:39:56', '2025-02-27 18:39:56'),
(30, '2025-02-27 19:34:09', 11, 25, '2025-02-27 19:34:09', '2025-02-27 19:34:09'),
(31, '2025-02-27 19:48:43', 11, 26, '2025-02-27 19:48:43', '2025-02-27 19:48:43'),
(32, '2025-02-28 12:05:39', 11, 27, '2025-02-28 12:05:39', '2025-02-28 12:05:39'),
(33, '2025-03-01 12:48:17', 11, 28, '2025-03-01 12:48:17', '2025-03-01 12:48:17'),
(34, '2025-03-01 13:13:49', 11, 29, '2025-03-01 13:13:49', '2025-03-01 13:13:49'),
(35, '2025-03-01 18:59:53', 11, 30, '2025-03-01 18:59:53', '2025-03-01 18:59:53'),
(36, '2025-03-07 11:10:37', 11, 31, '2025-03-07 11:10:37', '2025-03-07 11:10:37'),
(37, '2025-03-07 11:11:23', 11, 32, '2025-03-07 11:11:23', '2025-03-07 11:11:23'),
(38, '2025-03-18 10:15:25', 11, 33, '2025-03-18 10:15:25', '2025-03-18 10:15:25'),
(39, '2025-03-18 10:16:52', 11, 34, '2025-03-18 10:16:52', '2025-03-18 10:16:52'),
(40, '2025-03-18 10:41:03', 12, 35, '2025-03-18 10:41:03', '2025-03-18 10:41:03'),
(41, '2025-03-18 10:42:20', 11, 36, '2025-03-18 10:42:20', '2025-03-18 10:42:20'),
(42, '2025-03-18 10:46:30', 12, 37, '2025-03-18 10:46:30', '2025-03-18 10:46:30'),
(43, '2025-03-18 13:59:06', 11, 38, '2025-03-18 13:59:06', '2025-03-18 13:59:06'),
(44, '2025-04-02 04:33:31', 11, 39, '2025-04-02 04:33:31', '2025-04-02 04:33:31'),
(45, '2025-04-02 04:36:55', 11, 40, '2025-04-02 04:36:55', '2025-04-02 04:36:55'),
(46, '2025-04-02 04:38:06', 11, 41, '2025-04-02 04:38:06', '2025-04-02 04:38:06'),
(47, '2025-04-02 16:15:17', 11, 42, '2025-04-02 16:15:17', '2025-04-02 16:15:17'),
(48, '2025-04-02 16:59:14', 11, 43, '2025-04-02 16:59:14', '2025-04-02 16:59:14'),
(49, '2025-04-03 00:18:28', 11, 44, '2025-04-03 00:18:28', '2025-04-03 00:18:28'),
(50, '2025-04-03 00:55:11', 11, 45, '2025-04-03 00:55:11', '2025-04-03 00:55:11'),
(51, '2025-04-03 12:01:52', 11, 46, '2025-04-03 12:01:52', '2025-04-03 12:01:52'),
(52, '2025-04-04 23:40:29', 12, 47, '2025-04-04 23:40:29', '2025-04-04 23:40:29'),
(53, '2025-04-05 00:08:23', 11, 48, '2025-04-05 00:08:23', '2025-04-05 00:08:23'),
(54, '2025-04-05 15:05:13', 11, 49, '2025-04-05 15:05:13', '2025-04-05 15:05:13'),
(55, '2025-04-05 15:08:40', 11, 50, '2025-04-05 15:08:40', '2025-04-05 15:08:40'),
(56, '2025-04-05 17:22:18', 11, 51, '2025-04-05 17:22:18', '2025-04-05 17:22:18'),
(57, '2025-04-06 01:51:24', 11, 52, '2025-04-06 01:51:24', '2025-04-06 01:51:24'),
(58, '2025-04-06 15:36:18', 12, 53, '2025-04-06 14:36:18', '2025-04-06 14:36:18'),
(59, '2025-04-06 15:41:20', 12, 54, '2025-04-06 14:41:20', '2025-04-06 14:41:20'),
(60, '2025-04-06 15:51:31', 12, 55, '2025-04-06 14:51:31', '2025-04-06 14:51:31'),
(61, '2025-04-09 15:19:18', 12, 56, '2025-04-09 14:19:18', '2025-04-09 14:19:18'),
(62, '2025-04-09 15:34:58', 12, 57, '2025-04-09 14:34:58', '2025-04-09 14:34:58'),
(63, '2025-04-09 15:44:05', 12, 58, '2025-04-09 14:44:05', '2025-04-09 14:44:05'),
(64, '2025-04-09 16:13:19', 12, 59, '2025-04-09 15:13:19', '2025-04-09 15:13:19');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('dpDrEzi3Asz6qUTpzF4S5DLnWHBqsxDkGwBcKB3z', 12, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSWpnaXh6cFBFbTcwMUJvYjBDMHk2b2Zac1Eya0NWVFdNNVV5aXNpRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9wcm9maWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxMjt9', 1744233711);

-- --------------------------------------------------------

--
-- Table structure for table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(255) NOT NULL,
  `CIN` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `ADMIN` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom`, `CIN`, `email`, `password`, `telephone`, `ADMIN`, `created_at`, `updated_at`) VALUES
(4, 'youssef', 'CB111', 'youssef@youssef', '$2y$12$5/XasNbdKaNJ2WYkl2.v6e6iP5j77Ji5oRM9bETxamY3U5oIAnQ1C', '12345678', 0, '2024-11-04 12:51:21', '2024-11-04 12:51:21'),
(5, 'reda', 'KS555', 'reda@reda', '$2y$12$MSB8PG8L.snR5b68j1V8COKabhv66Vi.UGugHDbX2XrSaWepBsdrm', '123458', 0, '2024-11-05 10:23:19', '2024-11-05 10:23:19'),
(6, 'ahmed', 'C23456', 'ahmed@az', '$2y$12$ZEq6zuG1Unl1HoZJEN0DzOMZJNI3EveBzeyYzPG2dgKSpkcbKemGC', '2255225364', 0, '2024-11-18 13:05:53', '2024-11-18 13:05:53'),
(7, 'rachid', 'C55311', 'rachid@rachid.com', '$2y$12$KbNZs2lzNHAGfUUqxgcr2OZsAJOsmfTk4yKGGqewMHwNoDb13yWje', '064546217', 0, '2024-11-18 15:59:49', '2024-11-18 15:59:49'),
(8, 'yousscef', 'C6666', 'youssef@su', '$2y$12$JUMlxFg0krA3UBEvSilf4u7FyJr/2.uIlGEpEPz0vOge/E8KQP8CC', '555555555', 0, '2024-11-30 17:24:30', '2024-11-30 17:24:30'),
(9, 'youssef', 'C1111', 'youssef@youssef', '$2y$12$1a8HCrpFUWZ.0qieeHFfl.9p/yC5wPdedC49I2tajvR1h5ORuNfea', '111111111', 0, '2024-12-03 10:43:55', '2024-12-03 10:43:55'),
(10, 'scscsc', 'C2222', 'cscsc@scssc', '$2y$12$OMt9tbUXwbRiF3w43eG/Gu0bwxqUZ0SrxKPA.QNzIbV/v214SXH/y', '2222222', 0, '2024-12-04 14:33:51', '2024-12-04 14:33:51'),
(11, 'Youssef jk', 'azerty', 'azertya@gmail.com', '$2y$12$cFUkEDYAbFBe751nbHJX1OeaU3pfdF.6AZQ/tdruQ88b0k4RV4m5O', '000000000', 1, '2025-02-13 22:45:01', '2025-02-13 22:45:01'),
(12, 'Jaber', 'jaber', 'Cho3la@gmail.com', '$2y$12$2mRxQB.29anq6n.GROVDtOw4A/bzJBWFLmhDKzYzAb76rHK.MLYJa', '0654545454', 0, '2025-03-18 10:19:27', '2025-03-18 10:19:27'),
(13, 'fvfvfv', 'fvfvfv', 'fvfvf@vfv.fv', '$2y$12$8eys0kZMxkGqCu.d7v.qpOB52hJ8Gvg7ipv05856h7eB47RVVLrBO', '132323232', 1, '2025-04-06 13:14:59', '2025-04-06 13:14:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `detail_reservations`
--
ALTER TABLE `detail_reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `detail_reservations_ibfk_1` (`produit_id`),
  ADD KEY `detail_reservations_reservation_id_foreign` (`reservation_id`);

--
-- Indexes for table `factures`
--
ALTER TABLE `factures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `factures_utilisateur_id_foreign` (`utilisateur_id`);

--
-- Indexes for table `mails`
--
ALTER TABLE `mails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mails_utilisateur_id_foreign` (`email`),
  ADD KEY `Utilisateur` (`Utilisateur`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paniers`
--
ALTER TABLE `paniers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `produit_id` (`produit_id`),
  ADD KEY `paniers_ibfk_1` (`utilisateur_id`);

--
-- Indexes for table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `PR_CODE` (`PR_CODE`),
  ADD KEY `produits_categorie_id_foreign` (`PR_CATEGORIE`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reservations_utilisateur_id_foreign` (`utilisateur_id`),
  ADD KEY `facture` (`facture`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `CIN` (`CIN`,`email`,`telephone`),
  ADD UNIQUE KEY `CIN_2` (`CIN`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `detail_reservations`
--
ALTER TABLE `detail_reservations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `factures`
--
ALTER TABLE `factures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `mails`
--
ALTER TABLE `mails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `paniers`
--
ALTER TABLE `paniers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `produits`
--
ALTER TABLE `produits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_reservations`
--
ALTER TABLE `detail_reservations`
  ADD CONSTRAINT `detail_reservations_ibfk_1` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_reservations_reservation_id_foreign` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `factures`
--
ALTER TABLE `factures`
  ADD CONSTRAINT `factures_utilisateur_id_foreign` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`);

--
-- Constraints for table `mails`
--
ALTER TABLE `mails`
  ADD CONSTRAINT `mails_ibfk_1` FOREIGN KEY (`Utilisateur`) REFERENCES `utilisateurs` (`id`);

--
-- Constraints for table `paniers`
--
ALTER TABLE `paniers`
  ADD CONSTRAINT `paniers_ibfk_1` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`),
  ADD CONSTRAINT `paniers_ibfk_2` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`);

--
-- Constraints for table `produits`
--
ALTER TABLE `produits`
  ADD CONSTRAINT `produits_categorie_id_foreign` FOREIGN KEY (`PR_CATEGORIE`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`facture`) REFERENCES `factures` (`id`),
  ADD CONSTRAINT `reservations_utilisateur_id_foreign` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
